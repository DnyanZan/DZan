Imports System.IO

Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "


    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBaseUsername As System.Windows.Forms.TextBox
    Friend WithEvents txtBasePW As System.Windows.Forms.TextBox
    Friend WithEvents txtBaseDB As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnBuildBaseline As System.Windows.Forms.Button
    Friend WithEvents btnCompare As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtCompDB As System.Windows.Forms.TextBox
    Friend WithEvents txtCompPW As System.Windows.Forms.TextBox
    Friend WithEvents txtCompUsername As System.Windows.Forms.TextBox
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents grpComp As System.Windows.Forms.GroupBox
    Friend WithEvents tbBaselineInfo As System.Windows.Forms.TextBox
    Friend WithEvents tbCompInfo As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnBuildBaseline = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtBaseDB = New System.Windows.Forms.TextBox
        Me.txtBasePW = New System.Windows.Forms.TextBox
        Me.txtBaseUsername = New System.Windows.Forms.TextBox
        Me.tbBaselineInfo = New System.Windows.Forms.TextBox
        Me.grpComp = New System.Windows.Forms.GroupBox
        Me.tbCompInfo = New System.Windows.Forms.TextBox
        Me.btnCompare = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtCompDB = New System.Windows.Forms.TextBox
        Me.txtCompPW = New System.Windows.Forms.TextBox
        Me.txtCompUsername = New System.Windows.Forms.TextBox
        Me.StatusBar = New System.Windows.Forms.StatusBar
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.grpComp.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnBuildBaseline)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtBaseDB)
        Me.GroupBox1.Controls.Add(Me.txtBasePW)
        Me.GroupBox1.Controls.Add(Me.txtBaseUsername)
        Me.GroupBox1.Controls.Add(Me.tbBaselineInfo)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 128)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Create Baseline"
        '
        'btnBuildBaseline
        '
        Me.btnBuildBaseline.Location = New System.Drawing.Point(96, 96)
        Me.btnBuildBaseline.Name = "btnBuildBaseline"
        Me.btnBuildBaseline.TabIndex = 6
        Me.btnBuildBaseline.Text = "Build"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Database:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Username:"
        '
        'txtBaseDB
        '
        Me.txtBaseDB.Location = New System.Drawing.Point(72, 72)
        Me.txtBaseDB.Name = "txtBaseDB"
        Me.txtBaseDB.TabIndex = 2
        Me.txtBaseDB.Text = ""
        '
        'txtBasePW
        '
        Me.txtBasePW.Location = New System.Drawing.Point(72, 48)
        Me.txtBasePW.Name = "txtBasePW"
        Me.txtBasePW.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtBasePW.TabIndex = 1
        Me.txtBasePW.Text = ""
        '
        'txtBaseUsername
        '
        Me.txtBaseUsername.Location = New System.Drawing.Point(72, 24)
        Me.txtBaseUsername.Name = "txtBaseUsername"
        Me.txtBaseUsername.TabIndex = 0
        Me.txtBaseUsername.Text = ""
        '
        'tbBaselineInfo
        '
        Me.tbBaselineInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbBaselineInfo.Location = New System.Drawing.Point(176, 24)
        Me.tbBaselineInfo.Multiline = True
        Me.tbBaselineInfo.Name = "tbBaselineInfo"
        Me.tbBaselineInfo.ReadOnly = True
        Me.tbBaselineInfo.Size = New System.Drawing.Size(152, 96)
        Me.tbBaselineInfo.TabIndex = 15
        Me.tbBaselineInfo.Text = ""
        Me.tbBaselineInfo.WordWrap = False
        '
        'grpComp
        '
        Me.grpComp.Controls.Add(Me.tbCompInfo)
        Me.grpComp.Controls.Add(Me.btnCompare)
        Me.grpComp.Controls.Add(Me.Label4)
        Me.grpComp.Controls.Add(Me.Label5)
        Me.grpComp.Controls.Add(Me.Label6)
        Me.grpComp.Controls.Add(Me.txtCompDB)
        Me.grpComp.Controls.Add(Me.txtCompPW)
        Me.grpComp.Controls.Add(Me.txtCompUsername)
        Me.grpComp.Location = New System.Drawing.Point(8, 152)
        Me.grpComp.Name = "grpComp"
        Me.grpComp.Size = New System.Drawing.Size(336, 128)
        Me.grpComp.TabIndex = 1
        Me.grpComp.TabStop = False
        Me.grpComp.Text = "Compare Against Baseline"
        '
        'tbCompInfo
        '
        Me.tbCompInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbCompInfo.Location = New System.Drawing.Point(176, 24)
        Me.tbCompInfo.Multiline = True
        Me.tbCompInfo.Name = "tbCompInfo"
        Me.tbCompInfo.ReadOnly = True
        Me.tbCompInfo.Size = New System.Drawing.Size(152, 96)
        Me.tbCompInfo.TabIndex = 16
        Me.tbCompInfo.Text = ""
        Me.tbCompInfo.Visible = False
        Me.tbCompInfo.WordWrap = False
        '
        'btnCompare
        '
        Me.btnCompare.Location = New System.Drawing.Point(96, 96)
        Me.btnCompare.Name = "btnCompare"
        Me.btnCompare.TabIndex = 6
        Me.btnCompare.Text = "Compare"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Database:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Password:"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 23)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Username:"
        '
        'txtCompDB
        '
        Me.txtCompDB.Location = New System.Drawing.Point(72, 72)
        Me.txtCompDB.Name = "txtCompDB"
        Me.txtCompDB.TabIndex = 2
        Me.txtCompDB.Text = ""
        '
        'txtCompPW
        '
        Me.txtCompPW.Location = New System.Drawing.Point(72, 48)
        Me.txtCompPW.Name = "txtCompPW"
        Me.txtCompPW.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtCompPW.TabIndex = 1
        Me.txtCompPW.Text = ""
        '
        'txtCompUsername
        '
        Me.txtCompUsername.Location = New System.Drawing.Point(72, 24)
        Me.txtCompUsername.Name = "txtCompUsername"
        Me.txtCompUsername.TabIndex = 0
        Me.txtCompUsername.Text = ""
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(0, 298)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Size = New System.Drawing.Size(546, 22)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.TabIndex = 14
        Me.StatusBar.Text = "Ready."
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(352, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(184, 184)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "The first time you run this application, you will need to create a ""baseline"" usi" & _
        "ng the information on the top. This will create an xml file that represents the " & _
        "database structure of the source schema. Then, you can compare other database sc" & _
        "hemas to this baseline by using the information on the bottom."
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(546, 320)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.grpComp)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Oracle Schema Compare v1.0"
        Me.GroupBox1.ResumeLayout(False)
        Me.grpComp.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Form-level Events"
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' TODO: Load prefs
        LoadPrefs()

        ' TODO: Check for existing baseline
        CheckForBaseline()

    End Sub
    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        SavePrefs()
    End Sub
#End Region

#Region "Button Handlers"
    Private Sub btnBuildBaseline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildBaseline.Click
        If txtBaseUsername.Text = "" Then
            MessageBox.Show("Please enter login credentials.")
            Return
        End If

        StatusBar.Text = "Building baseline..."
        Dim ConnString As String = "user id=" & txtBaseUsername.Text & ";data source=" & txtBaseDB.Text & ";password=" & txtBasePW.Text
        Try
            Dim dsMaster As DataSet
            Dim infoBase As New OracleCompare
            'MissingTables.Rows.Clear()
            dsMaster = infoBase.BuildSchemaInfo(ConnString, txtBaseUsername.Text & "@" & txtBaseDB.Text)
            dsMaster.WriteXml("Baseline.xml")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        StatusBar.Text = "Baseline built."
        CheckForBaseline()
    End Sub

    Private Sub btnCompare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompare.Click
        Dim ConnString As String = "user id=" & txtCompUsername.Text & ";data source=" & txtCompDB.Text & ";password=" & txtCompPW.Text
        StatusBar.Text = "Comparing..."
        Try
            Dim dsComp As DataSet
            Dim dsMaster As New DataSet("Info")
            dsMaster.ReadXml("Baseline.xml")

            Dim infoBase As New OracleCompare

            dsComp = infoBase.BuildSchemaInfo(ConnString, txtCompUsername.Text & "@" & txtCompDB.Text)
            tbCompInfo.Text = ""
            For Each dr As DataRow In dsComp.Tables("INFO").Rows
                tbCompInfo.Text += dr("NAME") & " = " & dr("VALUE") & vbCrLf
            Next
            tbCompInfo.Visible = True
            infoBase.Compare(dsMaster, dsComp, "ReconcileLog.txt")

            Shell("Notepad ReconcileLog.txt", AppWinStyle.NormalFocus, False)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        StatusBar.Text = "Compare complete."
    End Sub

    Private Sub CheckForBaseline()
        grpComp.Enabled = False
        tbBaselineInfo.Visible = False
        tbBaselineInfo.Text = ""
        If File.Exists("Baseline.xml") Then
            grpComp.Enabled = True
            tbBaselineInfo.Visible = True
            Dim ds As New DataSet
            ds.ReadXml("Baseline.xml")
            For Each dr As DataRow In ds.Tables("INFO").Rows
                tbBaselineInfo.Text += dr("NAME") & " = " & dr("VALUE") & vbCrLf
            Next
        End If

    End Sub
#End Region

#Region "Loading Prefs"
    Private Sub LoadPrefs()
        If Not File.Exists("Config.xml") Then
            Return
        End If
        Dim ds As New DataSet("Config")
        ds.ReadXml("Config.xml")

        txtBaseUsername.Text = GetPref(ds, "BaseUsername")
        txtBasePW.Text = Encryption.Crypt(GetPref(ds, "BasePW"))
        txtBaseDB.Text = GetPref(ds, "BaseDB")

        txtCompUsername.Text = GetPref(ds, "CompUsername")
        txtCompPW.Text = Encryption.Crypt(GetPref(ds, "CompPW"))
        txtCompDB.Text = GetPref(ds, "CompDB")
    End Sub
    Private Function GetPref(ByVal ds As DataSet, ByVal Name As String) As String
        Try
            Dim dr() As DataRow = ds.Tables("Parms").Select("Name='" & Name & "'")
            If UBound(dr) = -1 Then
                Return ""
            End If
            Return dr(0)("Value")
        Catch ex As Exception
            Return ""
        End Try
    End Function
#End Region

#Region "Saving Preferences"
    Private Sub SavePrefs()
        Dim ds As New DataSet("Config")
        Dim dt As New DataTable("Parms")
        dt.Columns.Add("Name")
        dt.Columns.Add("Value")

        AddRow(dt, "BaseUsername", txtBaseUsername.Text)
        AddRow(dt, "BasePW", Encryption.Crypt(txtBasePW.Text))
        AddRow(dt, "BaseDB", txtBaseDB.Text)

        AddRow(dt, "CompUsername", txtCompUsername.Text)
        AddRow(dt, "CompPW", Encryption.Crypt(txtCompPW.Text))
        AddRow(dt, "CompDB", txtCompDB.Text)

        ds.Tables.Add(dt)
        ds.WriteXml("Config.xml")
    End Sub
    Private Sub AddRow(ByVal dt As DataTable, ByVal Name As String, ByVal Value As String)
        Dim dr As DataRow = dt.NewRow
        dr("Name") = Name
        dr("Value") = Value
        dt.Rows.Add(dr)
    End Sub
#End Region

End Class
