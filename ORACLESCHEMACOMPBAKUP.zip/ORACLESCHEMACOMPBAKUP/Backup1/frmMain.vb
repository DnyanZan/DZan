Imports System.IO

Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "


    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBaseUsername As System.Windows.Forms.TextBox
    Friend WithEvents txtBasePW As System.Windows.Forms.TextBox
    Friend WithEvents txtBaseDB As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnBuildBaseline As System.Windows.Forms.Button
    Friend WithEvents btnCompare As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtCompDB As System.Windows.Forms.TextBox
    Friend WithEvents txtCompPW As System.Windows.Forms.TextBox
    Friend WithEvents txtCompUsername As System.Windows.Forms.TextBox
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents grpComp As System.Windows.Forms.GroupBox
    Friend WithEvents tbBaselineInfo As System.Windows.Forms.TextBox
    Friend WithEvents tbCompInfo As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtBaseSQLSERVER As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtCmpSQLSERVER As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtBaseSQLSERVER = New System.Windows.Forms.TextBox
        Me.btnBuildBaseline = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtBaseDB = New System.Windows.Forms.TextBox
        Me.txtBasePW = New System.Windows.Forms.TextBox
        Me.txtBaseUsername = New System.Windows.Forms.TextBox
        Me.tbBaselineInfo = New System.Windows.Forms.TextBox
        Me.grpComp = New System.Windows.Forms.GroupBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtCmpSQLSERVER = New System.Windows.Forms.TextBox
        Me.tbCompInfo = New System.Windows.Forms.TextBox
        Me.btnCompare = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtCompDB = New System.Windows.Forms.TextBox
        Me.txtCompPW = New System.Windows.Forms.TextBox
        Me.txtCompUsername = New System.Windows.Forms.TextBox
        Me.StatusBar = New System.Windows.Forms.StatusBar
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.Label7 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.GroupBox1.SuspendLayout()
        Me.grpComp.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtBaseSQLSERVER)
        Me.GroupBox1.Controls.Add(Me.btnBuildBaseline)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtBaseDB)
        Me.GroupBox1.Controls.Add(Me.txtBasePW)
        Me.GroupBox1.Controls.Add(Me.txtBaseUsername)
        Me.GroupBox1.Controls.Add(Me.tbBaselineInfo)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 35)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 153)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Create Baseline"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 98)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 23)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "SQL Server"
        '
        'txtBaseSQLSERVER
        '
        Me.txtBaseSQLSERVER.Location = New System.Drawing.Point(72, 98)
        Me.txtBaseSQLSERVER.Name = "txtBaseSQLSERVER"
        Me.txtBaseSQLSERVER.Size = New System.Drawing.Size(100, 20)
        Me.txtBaseSQLSERVER.TabIndex = 16
        '
        'btnBuildBaseline
        '
        Me.btnBuildBaseline.Location = New System.Drawing.Point(104, 124)
        Me.btnBuildBaseline.Name = "btnBuildBaseline"
        Me.btnBuildBaseline.Size = New System.Drawing.Size(75, 23)
        Me.btnBuildBaseline.TabIndex = 6
        Me.btnBuildBaseline.Text = "Build"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Database:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Username:"
        '
        'txtBaseDB
        '
        Me.txtBaseDB.Location = New System.Drawing.Point(72, 72)
        Me.txtBaseDB.Name = "txtBaseDB"
        Me.txtBaseDB.Size = New System.Drawing.Size(100, 20)
        Me.txtBaseDB.TabIndex = 2
        '
        'txtBasePW
        '
        Me.txtBasePW.Location = New System.Drawing.Point(72, 48)
        Me.txtBasePW.Name = "txtBasePW"
        Me.txtBasePW.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtBasePW.Size = New System.Drawing.Size(100, 20)
        Me.txtBasePW.TabIndex = 1
        '
        'txtBaseUsername
        '
        Me.txtBaseUsername.Location = New System.Drawing.Point(72, 24)
        Me.txtBaseUsername.Name = "txtBaseUsername"
        Me.txtBaseUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtBaseUsername.TabIndex = 0
        '
        'tbBaselineInfo
        '
        Me.tbBaselineInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbBaselineInfo.Location = New System.Drawing.Point(176, 24)
        Me.tbBaselineInfo.Multiline = True
        Me.tbBaselineInfo.Name = "tbBaselineInfo"
        Me.tbBaselineInfo.ReadOnly = True
        Me.tbBaselineInfo.Size = New System.Drawing.Size(152, 96)
        Me.tbBaselineInfo.TabIndex = 15
        Me.tbBaselineInfo.WordWrap = False
        '
        'grpComp
        '
        Me.grpComp.Controls.Add(Me.Label9)
        Me.grpComp.Controls.Add(Me.txtCmpSQLSERVER)
        Me.grpComp.Controls.Add(Me.tbCompInfo)
        Me.grpComp.Controls.Add(Me.btnCompare)
        Me.grpComp.Controls.Add(Me.Label4)
        Me.grpComp.Controls.Add(Me.Label5)
        Me.grpComp.Controls.Add(Me.Label6)
        Me.grpComp.Controls.Add(Me.txtCompDB)
        Me.grpComp.Controls.Add(Me.txtCompPW)
        Me.grpComp.Controls.Add(Me.txtCompUsername)
        Me.grpComp.Location = New System.Drawing.Point(4, 194)
        Me.grpComp.Name = "grpComp"
        Me.grpComp.Size = New System.Drawing.Size(336, 166)
        Me.grpComp.TabIndex = 1
        Me.grpComp.TabStop = False
        Me.grpComp.Text = "Compare Against Baseline"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(8, 95)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 23)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "SQL Server"
        '
        'txtCmpSQLSERVER
        '
        Me.txtCmpSQLSERVER.Location = New System.Drawing.Point(72, 98)
        Me.txtCmpSQLSERVER.Name = "txtCmpSQLSERVER"
        Me.txtCmpSQLSERVER.Size = New System.Drawing.Size(100, 20)
        Me.txtCmpSQLSERVER.TabIndex = 17
        '
        'tbCompInfo
        '
        Me.tbCompInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbCompInfo.Location = New System.Drawing.Point(176, 24)
        Me.tbCompInfo.Multiline = True
        Me.tbCompInfo.Name = "tbCompInfo"
        Me.tbCompInfo.ReadOnly = True
        Me.tbCompInfo.Size = New System.Drawing.Size(154, 96)
        Me.tbCompInfo.TabIndex = 16
        Me.tbCompInfo.Visible = False
        Me.tbCompInfo.WordWrap = False
        '
        'btnCompare
        '
        Me.btnCompare.Location = New System.Drawing.Point(104, 126)
        Me.btnCompare.Name = "btnCompare"
        Me.btnCompare.Size = New System.Drawing.Size(75, 23)
        Me.btnCompare.TabIndex = 6
        Me.btnCompare.Text = "Compare"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Database:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Password:"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 23)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Username:"
        '
        'txtCompDB
        '
        Me.txtCompDB.Location = New System.Drawing.Point(72, 72)
        Me.txtCompDB.Name = "txtCompDB"
        Me.txtCompDB.Size = New System.Drawing.Size(100, 20)
        Me.txtCompDB.TabIndex = 2
        '
        'txtCompPW
        '
        Me.txtCompPW.Location = New System.Drawing.Point(72, 48)
        Me.txtCompPW.Name = "txtCompPW"
        Me.txtCompPW.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtCompPW.Size = New System.Drawing.Size(100, 20)
        Me.txtCompPW.TabIndex = 1
        '
        'txtCompUsername
        '
        Me.txtCompUsername.Location = New System.Drawing.Point(72, 24)
        Me.txtCompUsername.Name = "txtCompUsername"
        Me.txtCompUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtCompUsername.TabIndex = 0
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(0, 366)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Size = New System.Drawing.Size(627, 22)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.TabIndex = 14
        Me.StatusBar.Text = "Ready."
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(55, 12)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(56, 17)
        Me.RadioButton1.TabIndex = 16
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Oracle"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(205, 12)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(74, 17)
        Me.RadioButton2.TabIndex = 17
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Sql Server"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Location = New System.Drawing.Point(409, 83)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(184, 129)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = resources.GetString("Label7.Text")
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(354, 43)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(261, 271)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 18
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(627, 388)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.grpComp)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Oracle/SQL Server Schema Compare"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpComp.ResumeLayout(False)
        Me.grpComp.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region "Form-level Events"
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' TODO: Load prefs
        LoadPrefs()

        ' TODO: Check for existing baseline
        CheckForBaseline()
        RadioButton1.Checked = True




    End Sub
    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        SavePrefs()
    End Sub
#End Region

#Region "Button Handlers"
    Private Sub btnBuildBaseline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildBaseline.Click
        If txtBaseUsername.Text = "" Then
            MessageBox.Show("Please enter login credentials.")
            Return
        End If

        StatusBar.Text = "Building baseline..."
        Dim ConnString As String = "user id=" & txtBaseUsername.Text & ";data source=" & txtBaseDB.Text & ";password=" & txtBasePW.Text
        Try
            Dim dsMaster As DataSet
            Dim infoBase As New OracleCompare
            'MissingTables.Rows.Clear()
            dsMaster = infoBase.BuildSchemaInfo(ConnString, txtBaseUsername.Text & "@" & txtBaseDB.Text)
            dsMaster.WriteXml("Baseline.xml")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        StatusBar.Text = "Baseline built."
        CheckForBaseline()
    End Sub

    Private Sub btnCompare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompare.Click
        Dim ConnString As String = "user id=" & txtCompUsername.Text & ";data source=" & txtCompDB.Text & ";password=" & txtCompPW.Text
        StatusBar.Text = "Comparing..."
        Try
            Dim dsComp As DataSet
            Dim dsMaster As New DataSet("Info")
            dsMaster.ReadXml("Baseline.xml")

            Dim infoBase As New OracleCompare

            dsComp = infoBase.BuildSchemaInfo(ConnString, txtCompUsername.Text & "@" & txtCompDB.Text)
            tbCompInfo.Text = ""
            For Each dr As DataRow In dsComp.Tables("INFO").Rows
                tbCompInfo.Text += dr("NAME") & " = " & dr("VALUE") & vbCrLf
            Next
            tbCompInfo.Visible = True
            infoBase.Compare(dsMaster, dsComp, "ReconcileLog.txt")

            Shell("Notepad ReconcileLog.txt", AppWinStyle.NormalFocus, False)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        StatusBar.Text = "Compare complete."
    End Sub

    Private Sub CheckForBaseline()
        grpComp.Enabled = False
        tbBaselineInfo.Visible = False
        tbBaselineInfo.Text = ""
        If File.Exists("Baseline.xml") Then
            grpComp.Enabled = True
            tbBaselineInfo.Visible = True
            Dim ds As New DataSet
            ds.ReadXml("Baseline.xml")
            For Each dr As DataRow In ds.Tables("INFO").Rows
                tbBaselineInfo.Text += dr("NAME") & " = " & dr("VALUE") & vbCrLf
            Next
        End If

    End Sub
#End Region

#Region "Loading Prefs"
    Private Sub LoadPrefs()
        If Not File.Exists("Config.xml") Then
            Return
        End If
        Dim ds As New DataSet("Config")
        ds.ReadXml("Config.xml")

        txtBaseUsername.Text = GetPref(ds, "BaseUsername")
        txtBasePW.Text = Encryption.Crypt(GetPref(ds, "BasePW"))
        txtBaseDB.Text = GetPref(ds, "BaseDB")

        txtCompUsername.Text = GetPref(ds, "CompUsername")
        txtCompPW.Text = Encryption.Crypt(GetPref(ds, "CompPW"))
        txtCompDB.Text = GetPref(ds, "CompDB")
    End Sub
    Private Function GetPref(ByVal ds As DataSet, ByVal Name As String) As String
        Try
            Dim dr() As DataRow = ds.Tables("Parms").Select("Name='" & Name & "'")
            If UBound(dr) = -1 Then
                Return ""
            End If
            Return dr(0)("Value")
        Catch ex As Exception
            Return ""
        End Try
    End Function
#End Region

#Region "Saving Preferences"
    Private Sub SavePrefs()
        Dim ds As New DataSet("Config")
        Dim dt As New DataTable("Parms")
        dt.Columns.Add("Name")
        dt.Columns.Add("Value")

        AddRow(dt, "BaseUsername", txtBaseUsername.Text)
        AddRow(dt, "BasePW", Encryption.Crypt(txtBasePW.Text))
        AddRow(dt, "BaseDB", txtBaseDB.Text)

        AddRow(dt, "CompUsername", txtCompUsername.Text)
        AddRow(dt, "CompPW", Encryption.Crypt(txtCompPW.Text))
        AddRow(dt, "CompDB", txtCompDB.Text)

        ds.Tables.Add(dt)
        ds.WriteXml("Config.xml")
    End Sub
    Private Sub AddRow(ByVal dt As DataTable, ByVal Name As String, ByVal Value As String)
        Dim dr As DataRow = dt.NewRow
        dr("Name") = Name
        dr("Value") = Value
        dt.Rows.Add(dr)
    End Sub
#End Region

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        txtCmpSQLSERVER.Show()
        txtBaseSQLSERVER.Show()
        Label8.Show()
        Label9.Show()
        PictureBox1.BackgroundImage = My.Resources.img_sql_server_ret
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch



    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        txtCmpSQLSERVER.Hide()
        txtBaseSQLSERVER.Hide()
        Label8.Hide()
        Label9.Hide()
        PictureBox1.BackgroundImage = My.Resources.img_oracle
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch


    End Sub


End Class
